
const menuToggle = document.getElementById('menuToggle');
const nav = document.getElementById('nav');
const navLinks = document.querySelectorAll('.nav-link');
const logo = document.getElementById('logo');


function openMenu() {
    nav.classList.add('active');
    menuToggle.classList.add('active');
    document.body.style.overflow = 'hidden'; 
}


function closeMenu() {
    nav.classList.remove('active');
    menuToggle.classList.remove('active');
    document.body.style.overflow = 'auto'; 
}


menuToggle.addEventListener('click', () => {
    if (nav.classList.contains('active')) {
        closeMenu();
    } else {
        openMenu();
    }
});


navLinks.forEach(link => {
    link.addEventListener('click', closeMenu);
});


logo.addEventListener('click', (e) => {
    if (window.innerWidth <= 768 && nav.classList.contains('active')) {
        e.preventDefault();
        closeMenu();
    }
});


document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && nav.classList.contains('active')) {
        closeMenu();
    }
});


window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
        closeMenu();
    }
});

function toggleHeart(el) {
  el.classList.toggle("liked");
  el.classList.toggle("fa-regular");
  el.classList.toggle("fa-solid");
}


function anne(){
    const message= encodeURIComponent()
    const lien = "https://wa.me/+2250576732167" + "?text=" + message
    window.open(lien,"_blank")
}

const Btn = document.querySelector('.btn2') 
Btn.addEventListener('click',()=> {
    anne()
}
 )


 


